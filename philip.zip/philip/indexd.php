<script src="jquery.min.js"></script>
<link href="bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="bootstrap.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
.navbar{
    background: #0c73cc	 !important;
	 height: 25px; //change 
}

.dropdown{
    border-radius:0;
    border:0;
}
.dropdown-menu{
    background: #0c73cc;
    border:0;
    top:80%;
    border-radius:0px 0px 5px 5px;
}
.dropdown-item:hover{
    background:#085ca5;
    color:#fff;
}
.dropdown-menu a{
    color:#fff;
} 
.navbar .nav-item .nav-link{
    color:#eee !important; 
    
}
.navbar .nav-item .nav-link:hover .navbar .nav-item .nav-link{
    color:red !important;
    
}

</style>

<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
<a class="navbar-brand" href="#"><img src="Epson-Logo.jpg" style="width:100px"/></a>
 
<nav class="navbar navbar-expand-sm navbar-light bg-light" >
  
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact us</a>
      </li>
      <li class="nav-item dropdown dmenu">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Dropdown link
      </a>
      <div class="dropdown-menu sm-menu">
        <a class="dropdown-item" href="#">Link 1</a>
        <a class="dropdown-item" href="#">Link 2</a>
        <a class="dropdown-item" href="#">Link 3</a>
      </div>
    </li>
     <li class="nav-item dropdown dmenu">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Dropdown link
      </a>
      <div class="dropdown-menu sm-menu">
        <a class="dropdown-item" href="#">Link 1</a>
        <a class="dropdown-item" href="#">Link 2</a>
        <a class="dropdown-item" href="#">Link 3</a>
        <a class="dropdown-item" href="#">Link 4</a>
        <a class="dropdown-item" href="#">Link 5</a>
        <a class="dropdown-item" href="#">Link 6</a>
      </div>
    </li>
    </ul>
 
</nav>
</div>
<!--  BUTTON -->
<button  class="navbar-toggler buttonclick" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
   <span class="navbar-toggler-icon">CLICK ME</span>
</button>
<script>
	$(document).ready(function () {
	$('.buttonclick').click();
	$('.navbar-light .dmenu').hover(function () {
			$(this).find('.sm-menu').first().stop(true, true).slideDown(150);
		}, function () {
			$(this).find('.sm-menu').first().stop(true, true).slideUp(105)
		});
	});
</script>